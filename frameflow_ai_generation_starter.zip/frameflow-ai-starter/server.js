import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 3000);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: "15mb" }));
app.use(express.static(path.join(__dirname, "public")));

function client() {
  if (!process.env.OPENAI_API_KEY) {
    const error = new Error("OPENAI_API_KEY is missing. Copy .env.example to .env and add your API key.");
    error.status = 503;
    throw error;
  }
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}
function handleError(res, err) {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || "Generation failed." });
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, imageModel: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare", video: "Requires video API access" });
});

/**
 * Generates storyboard images. Requests are sequential to avoid overwhelming
 * rate limits; keep batches small and review usage/cost before production.
 */
app.post("/api/storyboard/images", async (req, res) => {
  try {
    const openai = client();
    const frames = Array.isArray(req.body.frames) ? req.body.frames.slice(0, 8) : [];
    if (!frames.length) return res.status(400).json({ error: "Provide at least one storyboard frame." });
    const result = [];
    for (const frame of frames) {
      const prompt = String(frame.prompt || `${frame.title || "Storyboard shot"}: ${frame.action || ""}`).slice(0, 12000);
      const image = await openai.images.generate({
        model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-flare",
        prompt,
        size: "1536x1024",
        quality: "medium",
        output_format: "jpeg",
        n: 1
      });
      const b64 = image.data?.[0]?.b64_json;
      if (!b64) throw new Error("Image model did not return image data.");
      result.push({
        number: frame.number,
        title: frame.title || `Frame ${frame.number}`,
        imageUrl: `data:image/jpeg;base64,${b64}`
      });
    }
    res.json({ frames: result });
  } catch (err) { handleError(res, err); }
});

/**
 * Starts one short video generation job. Video API availability, model names,
 * durations, and response shape can vary by account/API version. This endpoint
 * uses the OpenAI Videos API if enabled for the configured account.
 */
app.post("/api/storyboard/video", async (req, res) => {
  try {
    const openai = client();
    const prompt = String(req.body.prompt || "").slice(0, 12000);
    if (!prompt.trim()) return res.status(400).json({ error: "Provide a video prompt." });

    // OpenAI's Videos API may not be enabled for every account. If the SDK
    // exposes the Videos resource, create a generation job and return its ID.
    if (!openai.videos?.create) {
      return res.status(501).json({
        error: "The installed OpenAI SDK/account does not expose video generation. Configure an eligible video provider in this endpoint."
      });
    }
    const video = await openai.videos.create({
      model: process.env.OPENAI_VIDEO_MODEL || "sora-2",
      prompt,
      seconds: "8",
      size: "1280x720"
    });
    res.json({
      id: video.id,
      status: video.status || "queued",
      statusUrl: `/api/storyboard/video/${encodeURIComponent(video.id)}`
    });
  } catch (err) { handleError(res, err); }
});

app.get("/api/storyboard/video/:id", async (req, res) => {
  try {
    const openai = client();
    if (!openai.videos?.retrieve) return res.status(501).json({ error: "Video status retrieval is not available in this SDK/account." });
    const video = await openai.videos.retrieve(req.params.id);
    res.json({ id: video.id, status: video.status, progress: video.progress, error: video.error || null });
  } catch (err) { handleError(res, err); }
});

app.listen(port, () => console.log(`FrameFlow Studio running at http://localhost:${port}`));
