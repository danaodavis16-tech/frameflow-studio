# FrameFlow Studio — AI generation starter

This package adds a secure server layer to the FrameFlow storyboard UI. The API key stays on the server and is never embedded in browser JavaScript.

## What works after setup
- **Generate AI frames:** posts each storyboard prompt to the OpenAI Images API and displays the generated frames in the page.
- **Make motion clip:** attempts to start a short video generation job through the OpenAI Videos API. Video API access and model availability depend on your OpenAI account. This starter returns the job/status endpoint; it does not yet fetch and stream a finished video file into the browser.

## Run locally
1. Install Node.js 20 or newer.
2. Unzip this folder.
3. In this folder, run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your API key in `.env` as `OPENAI_API_KEY=...`. Never put it in `public/index.html` or share it publicly.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## API key and billing
An OpenAI API key and API billing/credits are separate from a ChatGPT subscription. Image generations use API usage and may incur charges. Check current API pricing and confirm access before generating a full storyboard.

## Important limitations
- The image route generates up to 8 frames per request, sequentially. It uses one prompt per frame; recurring-character consistency is best-effort, not guaranteed.
- The video route is an integration starting point. Video generation endpoints, model access, request fields, and job output delivery may depend on current API support for your account. If the endpoint is not enabled, use a supported video provider and replace the route.
- This is a local starter, not a publicly hosted website. To share it with other people, deploy the Node app to a host that supports server-side environment variables and HTTPS.
- Before public launch, add authentication, request limits, per-user quotas, persistent job storage, moderation, and usage/cost controls.

## Current API docs
- Images: https://developers.openai.com/api/docs/guides/image-generation
- Videos / Sora: https://developers.openai.com/cookbook/examples/sora/sora2_prompting_guide
